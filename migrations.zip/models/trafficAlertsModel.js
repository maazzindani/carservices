const db = require('../config/db');

const TrafficAlert = {
  // Create a new traffic alert
  create: async ({ title, description, location, alert_type, user_id }) => {
    const [result] = await db.query(
      'INSERT INTO traffic_alerts (title, description, location, severity, user_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)',
      [title, description, location, alert_type, user_id]
    );
    return result.insertId; // Returns the ID of the created alert
  },

  // Find a traffic alert by ID
  findById: async (id) => {
    const [rows] = await db.query('SELECT * FROM traffic_alerts WHERE id = ?', [id]);
    return rows[0]; // Return the first matching row
  },

  // Get all traffic alerts
  findAll: async () => {
    const [rows] = await db.query('SELECT * FROM traffic_alerts ORDER BY created_at DESC');
    return rows; // Return all rows
  },

  // Update a traffic alert by ID
  update: async (id, { title, description, location, alert_type }) => {
    const [result] = await db.query(
      'UPDATE traffic_alerts SET title = ?, description = ?, location = ?, alert_type = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [title, description, location, alert_type, id]
    );
    return result.affectedRows > 0; // Return true if the update was successful
  },

  // Delete a traffic alert by ID
  delete: async (id) => {
    const [result] = await db.query('DELETE FROM traffic_alerts WHERE id = ?', [id]);
    return result.affectedRows > 0; // Return true if the delete was successful
  }
};

module.exports = TrafficAlert;
