const db = require('../config/db');
const { client } = require('../config/paypal');
const paypal = require('@paypal/checkout-server-sdk');

const Subscription = {
  // Create a new PayPal subscription entry in the database
  create: async ({ userId, paypalSubscriptionId, expiresAt, status }) => {
    const [result] = await db.query(
      `INSERT INTO user_subscriptions 
        (user_id, paypal_subscription_id, expires_at, status) 
       VALUES (?, ?, ?, ?)`,
      [userId, paypalSubscriptionId, expiresAt, status]
    );
    return result.insertId;
  },

  // Find a subscription by User ID
  findByUserId: async (userId) => {
    const [rows] = await db.query(
      `SELECT * FROM user_subscriptions WHERE user_id = ?`,
      [userId]
    );
    return rows[0];
  },

  // Get all subscriptions with details
  findAll: async () => {
    const query = `
      SELECT us.id AS subscription_id, u.name AS user_name, us.paypal_subscription_id, 
             us.expires_at, us.status, s.name AS plan_name, s.price
      FROM user_subscriptions us
      JOIN users u ON us.user_id = u.id
      JOIN subscriptions s ON us.subscription_id = s.id
      ORDER BY us.id;
    `;

    const [rows] = await db.query(query);
    return rows;
  },

  // Update a subscription (e.g., update expiry date or status)
  update: async (id, { expiresAt, status }) => {
    const [result] = await db.query(
      `UPDATE user_subscriptions 
       SET expires_at = ?, status = ? 
       WHERE id = ?`,
      [expiresAt, status, id]
    );
    return result.affectedRows > 0;
  },

  // Delete a subscription
  delete: async (id) => {
    const [result] = await db.query(
      `DELETE FROM user_subscriptions WHERE id = ?`,
      [id]
    );
    return result.affectedRows > 0;
  },

  // Handle PayPal Subscription Creation
  createPayPalSubscription: async ({ planId, subscriber }) => {
    const request = new paypal.subscriptions.SubscriptionsCreateRequest();
    request.requestBody({
      plan_id: planId,
      subscriber: subscriber,
      application_context: {
        brand_name: "Your Business Name",
        locale: "en-US",
        user_action: "SUBSCRIBE_NOW",
        return_url: "https://yourdomain.com/success",
        cancel_url: "https://yourdomain.com/cancel"
      }
    });

    const response = await client().execute(request);
    return {
      subscriptionId: response.result.id,
      status: response.result.status,
      expiresAt: response.result.billing_info.next_billing_time
    };
  },

  // Cancel a PayPal Subscription
  cancelPayPalSubscription: async (paypalSubscriptionId) => {
    const request = new paypal.subscriptions.SubscriptionsCancelRequest(paypalSubscriptionId);
    request.requestBody({
      reason: "User requested cancellation"
    });

    const response = await client().execute(request);
    return response.statusCode === 204; // 204 indicates success
  },

  // Fetch PayPal Subscription Details
  getPayPalSubscriptionDetails: async (paypalSubscriptionId) => {
    const request = new paypal.subscriptions.SubscriptionsGetRequest(paypalSubscriptionId);
    const response = await client().execute(request);
    return response.result;
  },

  // Check for Expired Subscriptions
  findExpiredSubscriptions: async () => {
    const [rows] = await db.query(`
      SELECT * FROM user_subscriptions 
      WHERE expires_at < CURRENT_TIMESTAMP AND status != 'canceled'
    `);
    return rows;
  }
};

module.exports = Subscription;
  