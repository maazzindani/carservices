// controllers/postController.js
const Post = require('../models/post');
const Image = require('../models/image');

// Create a new post
exports.createPost = async (req, res) => {
  try {
    console.log(req.body);
    const {
      title, description, tags, category_id, default_category,
      address, country, region, city, postcode, phone, email, website, user_id
    } = req.body;

    // Save the post
    const postId = await Post.create({
      title, description, tags, category_id, default_category,
      address, country, region, city, postcode, phone, email, website, user_id
    });

    // Save images if provided
    if (req.files) {
      for (const file of req.files) {
        await Image.create({
          post_id: postId,
          image_path: file.path // Assuming file path is accessible
        });
      }
    }

    res.status(201).json({ message: 'Post created successfully', postId });
    res.redirect("/"); // Adjust the URL path as necessary
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all posts with their images
exports.getPosts = async (req, res) => {
  try {
    const posts = await Post.findAll();
    const postsWithImages = await Promise.all(posts.map(async (post) => {
      const images = await Image.findByPostId(post.id);
      return { ...post, images: images };
    }));
    return postsWithImages;
  } catch (error) {
    console.log(error.message)
    res.status(500).json({ error: error.message });
  }
};

// Get all featured posts with their images
exports.getFeaturedPosts = async (req, res) => {
  try {
    // console.log('Kemchoooo');
    const posts = await Post.findFeaturedPosts();
    // console.log(posts.length);
    const postsWithImages = await Promise.all(posts.map(async (post) => {
      const images = await Image.findByPostId(post.id);
      return { ...post, images };
    }));

    return postsWithImages;
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


// Get all featured posts Sorted with their images
exports.getSortedFeaturedPosts = async (req, res) => {
  try {
    // console.log('Kemchoooo');
    // const {id} = req.body;
    const posts = await Post.findSortedFeaturedPosts(1);
    // console.log(posts.length);
    const postsWithImages = await Promise.all(posts.map(async (post) => {
      const images = await Image.findByPostId(post.id);
      return { ...post, images };
    }));

    return postsWithImages;
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


// Get a specific post by ID with images
exports.getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    const images = await Image.findByPostId(post.id);
    res.status(200).json({ ...post, images });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};