const db = require('../config/db');

const Store = {
  // Create a new store for a user
  create: async ({
    userId,
    storeName,
    storeDescription = '',
    storeLogo = '',
    storeBanner = '',
    businessName,
    companyRegNumber = null,
    businessEmail = null,
    businessNumber = null,
    businessAddress = null,
    phoneNumber = null,
    email = null,
    socialPlatforms = null
  }) => {
    const sqlQuery = `
      INSERT INTO stores (
        user_id, store_name, store_description, store_logo, store_banner,
        business_name, company_reg_number, business_email, business_number,
        business_address, phone_number, email, social_platforms
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const queryParams = [
      userId, storeName, storeDescription, storeLogo, storeBanner,
      businessName, companyRegNumber, businessEmail, businessNumber,
      businessAddress, phoneNumber, email, JSON.stringify(socialPlatforms)
    ];
    const [result] = await db.query(sqlQuery, queryParams);
    return result.insertId;
  },

  // Find a store by store ID
  findById: async (storeId) => {
    const [rows] = await db.query('SELECT * FROM stores WHERE id = ?', [storeId]);
    return rows[0]; // Returns the store info or undefined if not found
  },

  // Find a store by user ID
  findByUserId: async (userId) => {
    const [rows] = await db.query('SELECT * FROM stores WHERE user_id = ?', [userId]);
    return rows[0]; // Returns the store info or undefined if not found
  },

  // Update store information
  update: async (storeId, {
    storeName,
    storeDescription = '',
    storeLogo = '',
    storeBanner = '',
    businessName,
    companyRegNumber = null,
    businessEmail = null,
    businessNumber = null,
    businessAddress = null,
    phoneNumber = null,
    email = null,
    socialPlatforms = null
  }) => {
    const sqlQuery = `
      UPDATE stores SET
        store_name = ?, store_description = ?, store_logo = ?, store_banner = ?,
        business_name = ?, company_reg_number = ?, business_email = ?, business_number = ?,
        business_address = ?, phone_number = ?, email = ?, social_platforms = ?
      WHERE id = ?
    `;
    const queryParams = [
      storeName, storeDescription, storeLogo, storeBanner,
      businessName, companyRegNumber, businessEmail, businessNumber,
      businessAddress, phoneNumber, email, JSON.stringify(socialPlatforms), storeId
    ];
    await db.query(sqlQuery, queryParams);
    return true;
  },

  // Delete a store by ID
  delete: async (storeId) => {
    await db.query('DELETE FROM stores WHERE id = ?', [storeId]);
    return true;
  },

  // Get all stores
  getAllStores: async () => {
    const [rows] = await db.query('SELECT * FROM stores');
    return rows;
  },
};

module.exports = Store;
