const db = require('../config/db'); // Database connection file

// Fetch all categories from the database
const getAllCategories = async () => {
    try {
        const [categories] = await db.query('SELECT id, name FROM categories');
        return categories;
    } catch (error) {
        throw new Error('Database error: Unable to fetch categories');
    }
};

module.exports = { getAllCategories };
