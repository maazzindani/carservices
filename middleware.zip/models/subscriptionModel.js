const db = require('../config/db');

const Subscription = {
  // Create a new subscription
  create: async ({ name, price }) => {
    const [result] = await db.query(
      'INSERT INTO subscriptions (name, price) VALUES (?, ?)',
      [name, price]
    );
    return result.insertId;
  },

  // Find a subscription by ID
  findById: async (id) => {
    const [rows] = await db.query('SELECT * FROM subscriptions WHERE id = ?', [id]);
    return rows[0];
  },

  // Get all subscriptions with their features
findAll: async () => {
  const query = `
    SELECT s.id AS subscription_id, s.name AS subscription_name, s.price, 
           f.feature_name
    FROM subscriptions s
    LEFT JOIN subscription_features f ON s.id = f.subscription_id
    ORDER BY s.id;  -- Optional: order by subscription ID
  `;

  const [rows] = await db.query(query);

  // Process the rows to group features by subscription
  const subscriptions = {};
  rows.forEach(row => {
    const { subscription_id, subscription_name, price, feature_name } = row;

    if (!subscriptions[subscription_id]) {
      subscriptions[subscription_id] = {
        id: subscription_id,
        name: subscription_name,
        price: price,
        features: [],
      };
    }

    if (feature_name) {
      subscriptions[subscription_id].features.push(feature_name);
    }
  });

  return Object.values(subscriptions); // Return an array of subscriptions
},


  // Update a subscription by ID
  update: async (id, { name, price }) => {
    const [result] = await db.query(
      'UPDATE subscriptions SET name = ?, price = ? WHERE id = ?',
      [name, price, id]
    );
    return result.affectedRows > 0;
  },

  // Delete a subscription by ID
  delete: async (id) => {
    const [result] = await db.query('DELETE FROM subscriptions WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }
};

module.exports = Subscription;
