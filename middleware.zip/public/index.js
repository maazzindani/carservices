

function displayToast(text) {
    var x = document.getElementById("snackbar");
    // Set the message inside the snackbar
    x.innerHTML = text;
    // Add the "show" class to DIV
    x.className = "show";

    // After 3 seconds, remove the show class from DIV
    setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
}
async function loginUser() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    });
    const data = await response.json();
    if (response.ok) {
        // Save token to localStorage and close the modal
        localStorage.setItem('token', data.token);
        updateAuthUI(); // Update UI immediately after login
        $('#loginModal').modal('hide');
        displayToast("Logged In Successfully");
    } else {
        // Show error message
        document.getElementById('loginError').innerText = data.message;
        document.getElementById('loginError').style.display = 'block';
    }
}

async function signupUser() {
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const mobile = document.getElementById('signupMobileNumber').value;
    const dob = document.getElementById('signupDateOfBirth').value;
    const address = document.getElementById('signupPhysicalAddress').value;
    
    const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, mobile, dob, address, email, password })
    });

    const data = await response.json();

    if (response.ok) {
        // Save token to localStorage and close the modal
        localStorage.setItem('token', data.token);
        $('#signUpModal').modal('hide');
        displayToast("Signed Up Successfully");
    } else {
        // Show error message
        document.getElementById('signUpError').innerText = data.message;
        document.getElementById('signUpError').style.display = 'block';
    }
}


function toggleModal(currentModalId, targetModalId) {
    // Close the current modal
    $(`#${currentModalId}`).modal('hide');

    // Wait for the current modal to hide before showing the target modal
    $(`#${currentModalId}`).on('hidden.bs.modal', function () {
        // Open the target modal
        $(`#${targetModalId}`).modal('show');
        // Remove the 'hidden' event handler to prevent repeated firing
        $(this).off('hidden.bs.modal');
    });
}

// Check if user is logged in
function checkUserAuth() {
    const token = localStorage.getItem('token');
    const loginButton = document.getElementById('login-button');
    const postAdButton = document.getElementById('post-ad-dropdown');


    if (token) {
        // User is logged in
        loginButton.classList.add('d-none'); // Hide login button
        postAdButton.classList.remove('d-none'); // Show post ad button
    } else {
        // User is not logged in
        loginButton.classList.remove('d-none'); // Show login button
        postAdButton.classList.add('d-none'); // Hide post ad button
    }
}

// Call checkUserAuth on page load
document.addEventListener('DOMContentLoaded', checkUserAuth);


function updateAuthUI() {
    const token = localStorage.getItem('token');
    const loginButton = document.getElementById('login-button');
    const postAdButton = document.getElementById('post-ad-button');

    if (token) {
        // User is logged in
        loginButton.classList.add('d-none'); // Hide login button
        postAdButton.classList.remove('d-none'); // Show post ad button
    } else {
        // User is not logged in
        loginButton.classList.remove('d-none'); // Show login button
        postAdButton.classList.add('d-none'); // Hide post ad button
    }
}