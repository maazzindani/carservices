const express = require('express');
const dotenv = require('dotenv');
const authRoutes = require('./routes/authRoutes'); // Import authRoutes
const subscriptionRoutes = require('./routes/subscriptionRoutes'); // Import subscriptionRoutes
const postRoutes = require('./routes/posts');
const categoryRoutes = require('./routes/categoryRoutes');
const userRoutes = require('./routes/userRoutes');
const postController = require('./controllers/postController');
const trafficAlertRoutes = require('./routes/trafficalertsRoutes');
const storeRoutes = require('./routes/storeRoutes');
const i18n = require('i18n');



// Load environment variables
dotenv.config();

// Configure i18n
i18n.configure({
  locales: ['en', 'es', 'fr'], // Supported languages, add more as needed
  directory: __dirname + '/locales', // Path to language files
  defaultLocale: 'en',
  cookie: 'lang', // To remember the language setting in cookies
}); 






const app = express();

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files from the "public" folder
app.use(express.static('public'));

// Serve static files from the "uploads" folder
app.use('/uploads', express.static('uploads')); // <-- Added to serve images from uploads

// Middleware
app.use(express.json());

// Route for the homepage
app.get('/', (req, res) => {
  res.render('index', { title: 'Car Services Ltd' });
});

// Initialize i18n
app.use(i18n.init);

app.get('/change-language/:lang', (req, res) => {
  res.cookie('lang', req.params.lang); // Store language in a cookie
  res.setLocale(req.params.lang);
  res.redirect('back'); // Redirect back to the previous page
});


app.get('/search', async (req, res) => {
  // Fetch all posts
  try {
    const posts = await postController.getPosts(); // Get all posts
    // console.log("Posts with images:", posts); // Add this line to verify data structure
    for (let index = 0; index < posts.length; index++) {
      const element = posts[index].images;
      console.log(element);
    }
    res.render('search', { title: 'Car Services Ltd', posts });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});

app.get('/post-add', (req, res) => {
  res.render('post_an_add', { title: 'Car Services Ltd' });
});

// Route to get Sorted Featured posts
app.get('/featured/sorted', async (req, res) => {
  // Fetch all posts
  try {
    const posts = await postController.getSortedFeaturedPosts(); // Get all posts
    // console.log("Posts with images:", posts); // Add this line to verify data structure
    console.log(posts);
    // return posts;
    res.status(200).json(posts);
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});


app.get('/featured-posts', async (req, res) => {
  // Fetch all posts
  try {
    const posts = await postController.getFeaturedPosts(); // Get all posts
    // console.log("Posts with images:", posts); // Add this line to verify data structure
    console.log(posts);
    res.render('featured_posts', { title: 'Car Services Ltd', posts });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});


app.get('/promoted-posts', async (req, res) => {
  // Fetch all posts
  try {
    const posts = await postController.getFeaturedPosts(); // Get all posts
    // console.log("Posts with images:", posts); // Add this line to verify data structure
    console.log(posts);
    res.render('promoted_posts', { title: 'Car Services Ltd', posts });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});

app.get('/car-valuation', (req, res) => {
  res.render('calculators/car_valuation_calculator', { title: 'Car Services Ltd' });
});

app.get('/car-finance', (req, res) => { 
  res.render('calculators/car_finance_calulator', { title: 'Car Services Ltd' });
});

app.get('/car-depreciation', (req, res) => {
  res.render('calculators/car_depreciation_calculator', { title: 'Car Services Ltd' });
});

app.get('/car-insurance-cost-calculator', (req, res) => {
  res.render('calculators/car_insurance_cost_calculator', { title: 'Car Services Ltd' });
});

app.get('/car-loan-calculator', (req, res) => {
  res.render('calculators/car_loan_calculator', { title: 'Car Services Ltd' });
});

app.get('/mileage-tax-calculator', (req, res) => {
  res.render('calculators/mileage_calculator', { title: 'Car Services Ltd' });
});

app.get('/fuel-efficiancy-calculator', (req, res) => {
  res.render('calculators/fuel_efficiency_calculator', { title: 'Car Services Ltd' });
});

app.get('/mileage-claim-calculator', (req, res) => {
  res.render('calculators/mileage_claim_calculator', { title: 'Car Services Ltd' });
});

app.get('/route-planner', (req, res) => {
  res.render('calculators/hgv_route_planner', { title: 'Car Services Ltd' });
});

app.get('/fuel-cost-calculator', (req, res) => {
  res.render('calculators/fuel_cost_calculator', { title: 'Car Services Ltd' });
});

app.get('/calculators', (req, res) => {
  res.render('calculators/select_calculator', { title: 'Car Services Ltd' });
});


app.get('/subscription', (req, res) => {
  res.render('subscription/subscription', { title: 'Car Services Ltd' });
});


app.get('/about', (req, res) => {
  res.render('about', { title: 'Car Services Ltd' });
});

app.get('/contact', (req, res) => {
  res.render('contact', { title: 'Car Services Ltd' });
});

app.get('/careers', (req, res) => {
  res.render('careers', { title: 'Car Services Ltd' });
});

app.get('/blog', (req, res) => {
  res.render('blog', { title: 'Car Services Ltd' });
});

app.get('/forum', (req, res) => {
  res.render('forum', { title: 'Car Services Ltd' });
});


app.get('/affiliate', (req, res) => {
  res.render('affiliate', { title: 'Car Services Ltd' });
});

app.get('/postTrafficAlert', (req, res) => {
  res.render('post_traffic_alert', { title: 'Car Services Ltd' });
});

app.get('/postStore', (req, res) => {
  res.render('post_store', { title: 'Car Services Ltd' });
});

app.get('/stores', (req, res) => {
  res.render('stores_list', { title: 'Car Services Ltd' });
});

app.get('/traffic-alerts', (req, res) => {
  res.render('traffic_alerts', { title: 'Car Services Ltd' });
});



// API routes
app.use('/api/auth', authRoutes); // Use authRoutes for login
app.use('/api/posts', postRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/users', userRoutes);
app.use('/api/trafficAlerts', trafficAlertRoutes);
app.use('/api/storeRoutes', storeRoutes);
app.use('/api/subscriptions', subscriptionRoutes); // Use subscriptionRoutes for subscription data


// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
