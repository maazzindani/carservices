// stripeConfig.js
const stripe = require('stripe')('your_stripe_secret_key');
module.exports = stripe;
