const db = require('../config/db');

async function runMigrations() {
  try {
    // ----- USERS TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        is_admin BOOLEAN DEFAULT FALSE,
        mobile_number VARCHAR(20),
        date_of_birth DATE,
        physical_address TEXT,
        profile_image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('Users table created or already exists');

    // ----- CATEGORIES TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        parent_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
      );
    `);
    console.log('Categories table created or already exists');

    // ----- SUBSCRIPTIONS TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('Subscriptions table created or already exists');

    // ----- SUBSCRIPTION FEATURES TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS subscription_features (
        id INT AUTO_INCREMENT PRIMARY KEY,
        subscription_id INT,
        feature_name VARCHAR(100) NOT NULL,
        FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('Subscription Features table created or already exists');

    // ----- USER SUBSCRIPTIONS TABLE (PayPal & Stripe Support) -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS user_subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        subscription_id INT NOT NULL,
        stripe_customer_id VARCHAR(255),
        stripe_subscription_id VARCHAR(255),
        paypal_subscription_id VARCHAR(255),
        expires_at TIMESTAMP,
        status ENUM('active', 'expired', 'canceled') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
      );
    `);
    console.log('User subscriptions table created successfully.');

    // ----- POSTS TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS posts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        tags VARCHAR(255),
        category_id INT NOT NULL,
        user_id INT NOT NULL,
        address VARCHAR(255) NOT NULL,
        country VARCHAR(100) NOT NULL,
        city VARCHAR(100),
        postcode VARCHAR(20),
        phone VARCHAR(20),
        email VARCHAR(100),
        website VARCHAR(255),
        featured BOOLEAN DEFAULT FALSE,
        promoted BOOLEAN DEFAULT FALSE,
        store_page BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `);
    console.log('Posts table created or already exists');

    // ----- IMAGES TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS images (
        id INT AUTO_INCREMENT PRIMARY KEY,
        post_id INT NOT NULL,
        image_path VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
      );
    `);
    console.log('Images table created or already exists');

    // ----- TRAFFIC ALERTS TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS traffic_alerts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        location VARCHAR(255) NOT NULL,
        user_id INT NOT NULL,
        severity ENUM('low', 'medium', 'high') DEFAULT 'low',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `);
    console.log('Traffic Alerts table created or already exists');

    // ----- STORES TABLE -----
    await db.query(`
      CREATE TABLE IF NOT EXISTS stores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        store_name VARCHAR(255) NOT NULL,
        store_description TEXT,
        store_logo VARCHAR(255),
        store_banner VARCHAR(255),
        business_name VARCHAR(255),
        company_reg_number VARCHAR(255),
        business_email VARCHAR(255),
        business_address TEXT,
        phone_number VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `);
    console.log('Stores table created or already exists');

    await seedCategories();
    console.log('Categories seeded successfully');

    await seedSubscriptions();
    console.log('Subscriptions seeded successfully');

    await seedSubscriptionFeatures();
    console.log('Subscription seeded successfully');


  } catch (error) {
    console.error('Error running migrations:', error);
  } finally {
    db.end();
  }
}

async function seedCategories() {
  const categories = [
    { name: 'Traffic Issues Posts', parent_id: null },
    { name: 'Car for Sale', parent_id: 1 },
    { name: 'Car and Truck Parts', parent_id: 1 },
    { name: 'Car for Hire', parent_id: 1 },
    { name: 'Car Pooling', parent_id: 1 },
    { name: 'Car Share', parent_id: 1 },
    { name: 'Car/Truck Mechanics', parent_id: 1 },
    { name: 'Chaffeur/Drivers for Hire', parent_id: 1 },
    { name: 'Commercial Vehicle for Sale', parent_id: 1 },
    { name: 'Commercial Vehicle for Hire', parent_id: 1 },
    { name: 'Farm Equipment Sale', parent_id: 1 },
    { name: 'Other Services', parent_id: 1 },
    { name: 'Plant Equipment Hire & Sale', parent_id: 1 },
    { name: 'Tow Services', parent_id: 1 }
  ];

  for (const category of categories) {
    await db.query(`
      INSERT INTO categories (name, parent_id)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE name = VALUES(name);
    `, [category.name, category.parent_id]);
  }
}

async function seedSubscriptions() {
  await db.query(`
    INSERT INTO subscriptions (name, price) VALUES
      ('Silver', 100.00),
      ('Gold', 200.00),
      ('Platinum', 300.00)
    ON DUPLICATE KEY UPDATE price = VALUES(price);
  `);
}

async function seedSubscriptionFeatures() {
  const subscriptionFeatures = [
    // Platinum Package
    { subscription_name: 'Platinum', feature_name: 'Service Due Date Reminder' },
    { subscription_name: 'Platinum', feature_name: 'Insurance Reminder' },
    { subscription_name: 'Platinum', feature_name: 'Fuel Cost Calculator' },
    { subscription_name: 'Platinum', feature_name: 'Road Tax Reminder' },
    { subscription_name: 'Platinum', feature_name: 'Maps' },
    { subscription_name: 'Platinum', feature_name: 'Chat Support' },
    { subscription_name: 'Platinum', feature_name: 'Business or Store Page' },
    { subscription_name: 'Platinum', feature_name: '4 Sponsored Posts' },
    // Gold Package
    { subscription_name: 'Gold', feature_name: 'Service Due Date Reminder' },
    { subscription_name: 'Gold', feature_name: 'Insurance Reminder' },
    { subscription_name: 'Gold', feature_name: 'Fuel Cost Calculator' },
    { subscription_name: 'Gold', feature_name: 'Road Tax Reminder' },
    { subscription_name: 'Gold', feature_name: 'Maps' },
    { subscription_name: 'Gold', feature_name: 'Chat Support' },
    { subscription_name: 'Gold', feature_name: 'Business or Store Page' },
    { subscription_name: 'Gold', feature_name: '2 Sponsored Posts' },
    // Silver Package
    { subscription_name: 'Silver', feature_name: 'Service Due Date Reminder' },
    { subscription_name: 'Silver', feature_name: 'Insurance Reminder' },
    { subscription_name: 'Silver', feature_name: 'Calculators' },
    { subscription_name: 'Silver', feature_name: 'Road Tax Reminder' },
    { subscription_name: 'Silver', feature_name: 'Store Page' },
    { subscription_name: 'Silver', feature_name: 'Basic Support' },
  ];

  for (const feature of subscriptionFeatures) {
    // Get the subscription ID for the subscription name
    const [rows] = await db.query(`
      SELECT id FROM subscriptions WHERE name = ?;
    `, [feature.subscription_name]);

    if (rows.length > 0) {
      const subscriptionId = rows[0].id;
      await db.query(`
        INSERT INTO subscription_features (subscription_id, feature_name)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);
      `, [subscriptionId, feature.feature_name]);
    }
  }
  console.log('Subscription features seeded successfully.');
}

runMigrations();
