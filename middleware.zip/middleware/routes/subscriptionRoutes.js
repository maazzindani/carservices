// const express = require('express');
// const stripe = require('../config/stripeConfig');
// const db = require('../config/db');

// const router = express.Router();

// // 📝 Middleware for validating request body
// const validateSubscriptionRequest = (req, res, next) => {
//   const { userId, subscriptionId, paymentMethodId } = req.body;

//   if (!userId || !subscriptionId || !paymentMethodId) {
//     return res.status(400).json({ message: 'Missing required fields: userId, subscriptionId, or paymentMethodId' });
//   }
//   next();
// };

// // 💳 Create a new subscription charge
// router.post('/charge', validateSubscriptionRequest, async (req, res) => {
//   const { userId, subscriptionId, paymentMethodId } = req.body;

//   try {
//     // Fetch user and subscription details
//     const [userResult] = await db.query('SELECT * FROM users WHERE id = ?', [userId]);
//     const [subscriptionResult] = await db.query('SELECT * FROM subscriptions WHERE id = ?', [subscriptionId]);

//     if (!userResult || !subscriptionResult) {
//       return res.status(404).json({ message: 'User or subscription not found' });
//     }

//     const user = userResult;
//     const subscription = subscriptionResult;

//     // Create Stripe customer
//     const customer = await stripe.customers.create({
//       email: user.email,
//       payment_method: paymentMethodId,
//       invoice_settings: { default_payment_method: paymentMethodId }
//     });

//     // Create Stripe subscription
//     const stripeSubscription = await stripe.subscriptions.create({
//       customer: customer.id,
//       items: [{
//         price_data: {
//           product_data: { name: subscription.name },
//           unit_amount: subscription.price * 100,
//           currency: 'usd',
//           recurring: { interval: 'month' }
//         }
//       }],
//       expand: ['latest_invoice.payment_intent']
//     });

//     const paymentIntent = stripeSubscription.latest_invoice.payment_intent;

//     if (paymentIntent.status === 'succeeded') {
//       // Update user's subscription info in the database
//       await db.query(
//         `UPDATE users SET subscription_id = ?, subscription_expiration = ? WHERE id = ?`,
//         [subscriptionId, new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), userId]
//       );

//       return res.status(201).json({
//         message: 'Subscription successful',
//         status: 'active',
//         subscriptionId: stripeSubscription.id
//       });
//     } else {
//       return res.status(400).json({
//         message: 'Payment failed',
//         status: 'failed',
//         reason: paymentIntent.status
//       });
//     }
//   } catch (error) {
//     console.log(error);
//     console.error('Error processing subscription charge:', error);
//     res.status(500).json({ message: 'Internal server error' });
//   }
// });

// // 📆 Cancel an active subscription
// router.post('/cancel', async (req, res) => {
//   const { stripeSubscriptionId } = req.body;

//   if (!stripeSubscriptionId) {
//     return res.status(400).json({ message: 'Missing stripeSubscriptionId' });
//   }

//   try {
//     // Cancel the subscription on Stripe
//     await stripe.subscriptions.del(stripeSubscriptionId);

//     // Update the database status
//     await db.query(
//       `UPDATE users SET subscription_id = NULL, subscription_expiration = NULL WHERE subscription_id = ?`,
//       [stripeSubscriptionId]
//     );

//     return res.status(200).json({ message: 'Subscription canceled successfully' });
//   } catch (error) {
//     console.error('Error canceling subscription:', error);
//     res.status(500).json({ message: 'Failed to cancel subscription' });
//   }
// });

// // 📄 Get all subscriptions
// router.get('/subscriptions', async (req, res) => {
//   try {
//     const subscriptions = await db.query('SELECT * FROM subscriptions');
//     res.status(200).json(subscriptions);
//   } catch (error) {
//     console.error('Error fetching subscriptions:', error);
//     res.status(500).json({ message: 'Failed to fetch subscriptions' });
//   }
// });

// // 👤 Get user's active subscription
// router.get('/user/:userId/subscription', async (req, res) => {
//   const { userId } = req.params;

//   try {
//     const [userSubscription] = await db.query(
//       `SELECT * FROM subscriptions 
//        JOIN users ON subscriptions.id = users.subscription_id 
//        WHERE users.id = ?`, 
//       [userId]
//     );

//     if (!userSubscription) {
//       return res.status(404).json({ message: 'No active subscription found for this user' });
//     }

//     res.status(200).json(userSubscription);
//   } catch (error) {
//     console.error('Error fetching user subscription:', error);
//     res.status(500).json({ message: 'Failed to fetch user subscription' });
//   }
// });

// module.exports = router;


const express = require('express');
const Subscription = require('../models/subscriptionModel');
const router = express.Router();

// Route to get all subscriptions
router.get('/', async (req, res) => {
  try {
    const subscriptions = await Subscription.findAll();
    res.json(subscriptions);
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;
