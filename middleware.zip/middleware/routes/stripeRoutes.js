const express = require('express');
const stripe = require('../config/stripeConfig');
const db = require('../config/db');
const router = express.Router();

// Endpoint to create a subscription charge
router.post('/charge', async (req, res) => {
  try {
    const { userId, subscriptionId, paymentMethodId } = req.body;

    // Fetch user and subscription details
    const userResult = await db.query('SELECT * FROM users WHERE id = ?', [userId]);
    const subscriptionResult = await db.query('SELECT * FROM subscriptions WHERE id = ?', [subscriptionId]);

    if (userResult.length === 0 || subscriptionResult.length === 0) {
      return res.status(404).json({ message: 'User or subscription not found' });
    }

    const user = userResult[0];
    const subscription = subscriptionResult[0];

    // Create a new Stripe customer or use an existing customer ID
    const customer = await stripe.customers.create({
      email: user.email,
      payment_method: paymentMethodId,
      invoice_settings: { default_payment_method: paymentMethodId },
    });

    // Attempt to create a subscription
    const subscriptionCharge = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price_data: { product: 'your_product_id', unit_amount: subscription.price * 100, currency: 'usd' }}],
      expand: ['latest_invoice.payment_intent'],
    });

    // Check if the subscription was successful
    const paymentIntent = subscriptionCharge.latest_invoice.payment_intent;
    if (paymentIntent.status === 'succeeded') {
      // Update user subscription info
      await db.query('UPDATE users SET subscription_id = ?, subscription_expiration = ? WHERE id = ?',
        [subscriptionId, new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), userId]);

      return res.json({ message: 'Subscription successful', status: 'active' });
    } else {
      return res.status(400).json({ message: 'Payment failed', status: 'failed' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});
