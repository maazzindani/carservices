const categoryModel = require('../models/categoryModel');

// Controller to get all categories
const fetchCategories = async (req, res) => {
    try {
        const categories = await categoryModel.getAllCategories();
        res.json(categories);
    } catch (error) {
        console.error('Error in fetchCategories:', error);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
};

module.exports = { fetchCategories };
