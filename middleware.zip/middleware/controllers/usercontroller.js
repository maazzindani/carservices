const User = require('../models/userModel');

exports.getAllUsers = async (req, res) => {
  try {
    // if (!req.user.isAdmin) return res.status(403).json({ message: 'Access denied' });
    const users = await User.findAll();
    res.json(users);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error fetching users' });
  }
};


// Get user by ID
exports.getUserById = async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await User.findById(userId); // Use findByPk to get user by primary key (id)

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching user' });
  }
};