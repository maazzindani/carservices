const Subscription = require('../models/subscriptionModel');
const { client } = require('../config/paypal');
const paypal = require('@paypal/checkout-server-sdk');

// Get all available subscriptions
exports.getSubscriptions = async (req, res) => {
  try {
    const subscriptions = await Subscription.findAll();
    res.status(200).json(subscriptions);
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    res.status(500).json({ error: 'Failed to fetch subscriptions' });
  }
};

// Subscribe a user to a plan
exports.subscribe = async (req, res) => {
  const { userId, planId } = req.body;

  try {
    // Create a PayPal subscription
    const subscriber = {
      name: req.user?.name || 'Anonymous',
      email_address: req.user?.email || 'no-email@example.com'
    };

    const subscriptionDetails = await Subscription.createPayPalSubscription({ planId, subscriber });

    // Save subscription details to the database
    const subscriptionId = await Subscription.create({
      userId,
      paypalSubscriptionId: subscriptionDetails.subscriptionId,
      expiresAt: new Date(subscriptionDetails.expiresAt),
      status: subscriptionDetails.status
    });

    res.status(201).json({ message: 'Subscription successful', subscriptionDetails });
  } catch (error) {
    console.error('Error creating subscription:', error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
};

// Cancel a subscription
exports.cancelSubscription = async (req, res) => {
  const { paypalSubscriptionId } = req.body;

  try {
    // Cancel subscription on PayPal
    const isCancelled = await Subscription.cancelPayPalSubscription(paypalSubscriptionId);
    if (!isCancelled) {
      return res.status(400).json({ error: 'Failed to cancel subscription on PayPal' });
    }

    // Update subscription status in the database
    const updated = await Subscription.update(paypalSubscriptionId, { status: 'canceled' });
    if (!updated) {
      return res.status(400).json({ error: 'Failed to update subscription status in database' });
    }

    res.status(200).json({ message: 'Subscription canceled successfully' });
  } catch (error) {
    console.error('Error canceling subscription:', error);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
};

// Retrieve a user's active subscription
exports.getUserSubscription = async (req, res) => {
  const { userId } = req.params;

  try {
    const subscription = await Subscription.findByUserId(userId);
    if (!subscription) {
      return res.status(404).json({ error: 'No active subscription found for this user' });
    }

    res.status(200).json(subscription);
  } catch (error) {
    console.error('Error fetching user subscription:', error);
    res.status(500).json({ error: 'Failed to fetch user subscription' });
  }
};
