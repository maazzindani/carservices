const mysql = require('mysql2/promise');
require('dotenv').config();

const db = mysql.createPool({
  host: '192.250.229.33',
  user: 'apnabusiness_new',
  password: 'q${NT9VtOYY0',
  database: 'apnabusiness_carservices',
  port: 3306
});

module.exports = db;
