const paypal = require('@paypal/checkout-server-sdk');

function environment() {
  const clientId = 'AYUYrXOFlav_4to-tgzfoAMYa9CfarGuljCplq0AdBlCcuW8Ha2SHKb6BL9QoQL2RcHcj6poyOKBfgpH';
  const clientSecret = 'EHgyGrrXaANn3wV4SbZzpjTHjCSTWAu37QW8hxWaLvQp125Pu8o1hVvCFbAkXyWqJ9GwGas6ysVKW1NI';

  return new paypal.core.SandboxEnvironment(clientId, clientSecret); // Use LiveEnvironment for production
}

function client() {
  return new paypal.core.PayPalHttpClient(environment());
}

module.exports = { client };
