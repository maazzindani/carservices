const express = require('express');
const router = express.Router();
const userController = require('../controllers/usercontroller');
// const { verifyToken } = require('../middleware/authMiddleware');

router.get('/', userController.getAllUsers);

router.get('/:id', userController.getUserById);



module.exports = router;
