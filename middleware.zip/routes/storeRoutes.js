const express = require('express');
const router = express.Router();
const storeController = require('../controllers/storeController');
const upload = require('../middleware/upload');

// Route for creating a new store
router.post('/stores', upload.fields([
    { name: 'store_logo', maxCount: 1 },
    { name: 'store_banner', maxCount: 1 }
]), storeController.createStore);

// Route for getting all stores
router.get('/stores', storeController.getStores);

// Route for getting a store by ID
router.get('/stores/:id', storeController.getStoreById);

// Route for getting a store by user ID
router.get('/stores/user/:userId', storeController.getStoreByUserId);

// Route for updating a store
router.put('/stores/:id', storeController.updateStore);

// Route for deleting a store
router.delete('/stores/:id', storeController.deleteStore);

module.exports = router;
