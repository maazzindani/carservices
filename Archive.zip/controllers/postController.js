// controllers/postController.js
const Post = require('../models/post');
const Image = require('../models/image');
const sanitizeHtml = require('sanitize-html'); // Install using: npm install sanitize-html
const { Op } = require('sequelize');



// Create a new post
exports.createPost = async (req, res) => {
  try {
    console.log(req.body);
    const {
      title, description, tags, category_id, default_category,
      address, country, region, city, postcode, phone, email, website, user_id
    } = req.body;

    // Save the post
    const postId = await Post.create({
      title, description, tags, category_id, default_category,
      address, country, region, city, postcode, phone, email, website, user_id
    });

    // Save images if provided
    if (req.files) {
      for (const file of req.files) {
      console.log("console.log(file.path);");
      console.log(file.path);
      await Image.create({
        post_id: postId,
        image_path: file.path // Assuming file path is accessible
      });
      }
    }

    res.status(201).json({ message: 'Post created successfully', postId });
    res.redirect("/"); // Adjust the URL path as necessary
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all posts with their images and pagination
exports.getPosts = async (req, res) => {
  try {
    console.log("Getting posts");
    const { page = 1, limit = 10, search = '', location = '' } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    // Modify query to support search and location filters
    const posts = await Post.findAll({
      where: {
        title: { [Op.like]: `%${search}%` },
        address: { [Op.like]: `%${location}%` },
      },
      page:page,
      offset,
      limit: parseInt(limit),
    });

    const postsWithImages = await Promise.all(
      posts.map(async (post) => {
        const images = await Image.findByPostId(post.id);
        return { ...post, images };
      })
    );

    const totalPosts = await Post.count({
      where: {
        title: { [Op.like]: `%${search}%` },
        address: { [Op.like]: `%${location}%` },
      },
    });

    const totalPages = Math.ceil(totalPosts / limit);

    res.status(200).json({
      posts: postsWithImages,
      currentPage: parseInt(page),
      totalPages,
      totalPosts,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ error: error.message });
  }
};



// Get all featured posts (or all posts if no featured posts) with pagination, search, location, and images
exports.getFeaturedPosts = async (req, res) => {
  try {
    console.log("req.query");
    console.log(req.query);
    const { page = 1, limit = 2, search = '', location = '' } = req.query;

    // Fetch the posts (either featured or all if no featured posts)
    const posts = await Post.findFeaturedPosts({
      page,
      limit,
      search,
      location,
    });
    console.log(posts);

    // Get images for each post
    const postsWithImages = await Promise.all(
      posts.map(async (post) => {
        const images = await Image.findByPostId(post.id);
        return { ...post, images };
      })
    );

    // Count the total number of posts (featured or all)
    const totalPosts = await Post.countFeaturedPosts({
      search,
      location,
    });

    const totalPages = Math.ceil(totalPosts / limit);

    // Send the response with pagination details
    res.status(200).json({
      posts: postsWithImages,
      currentPage: parseInt(page),
      totalPages,
      totalPosts,
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ error: error.message });
  }
};



// Get all featured posts Sorted with their images
exports.getSortedFeaturedPosts = async (req, res) => {
  try {
    // console.log('Kemchoooo');
    // const {id} = req.body;
    const posts = await Post.findSortedFeaturedPosts(1);
    // console.log(posts.length);
    const postsWithImages = await Promise.all(posts.map(async (post) => {
      const images = await Image.findByPostId(post.id);
      return { ...post, images };
    }));

    return postsWithImages;
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


// Get a specific post by ID with images
exports.getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    const images = await Image.findByPostId(post.id);
    res.status(200).json({ ...post, images });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};