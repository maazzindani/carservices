const Blogs = require('../models/blogsModel');
const BlogsImage = require('../models/blogs_images');

const slugify = require('slugify'); // You'll need to install this: npm install slugify


// Get all blogs
// Get all blogs with pagination and filters
exports.getAllBlogs = async (req, res) => {
    try {
        console.log("Getting blogs");

        const { page = 1, limit = 10, search = ''} = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);

        // Modify query to support search and location filters
        const blogs = await Blogs.findAll({
            page: page,
            limit: parseInt(limit),
            search: search,
            offset: offset
        });

        const totalBlogs = await Blogs.count({
            search: search
        });

        const totalPages = Math.ceil(totalBlogs / limit);

        res.status(200).json({
            blogs,
            currentPage: parseInt(page),
            totalPages,
            totalBlogs,
        });
    } catch (error) {
        console.error("Error fetching blogs:", error);
        res.status(500).json({ error: "Failed to fetch blogs" });
    }
};

// Get a single blog by ID
exports.getBlogById = async (req, res) => {
    const { id } = req.params;
    try {
        const blog = await Blogs.findById(id);
        if (!blog) {
            return res.status(404).json({ error: "Blog not found" });
        }
        res.status(200).json(blog);
    } catch (error) {
        console.error("Error fetching blog:", error);
        res.status(500).json({ error: "Failed to fetch blog" });
    }
};

// In your controller or service:
async function generateUniqueSlug(title) {
    let slug = slugify(title);
    let counter = 1;

    // Correct way to use your findOne or findBySlug method:
    while (await Blogs.findBySlug(slug)) { // Correct - Pass the slug value directly
        slug = slugify(title) + '-' + counter;
        counter++;
    }


    console.log(slug);

    return slug;
}

// Create a new blog
exports.createBlog = async (req, res) => {
    console.log("Hello");
    console.log(req.body);
    const { user_id, title, slug, content, image, excerpt, status } = req.body;
    try {
        const generatedSlug = await generateUniqueSlug(slug); // Generate unique slug
        console.log(generatedSlug);
        console.log({ user_id, title, generatedSlug, content, excerpt, status });
        const blogId = await Blogs.create({ user_id, title, slug: generatedSlug, content, excerpt, status });
        console.log('Blog Id');
        console.log(blogId);
        if (req.files) {
            // Assuming `req.files` is an array or object with the file data
            const imagePath = req.files.image ? req.files.image[0].path : null; // Extract file path
            if (imagePath) {
                // Add the image path to the blogs_images table
                await BlogsImage.create({ blog_id: blogId, image_path: imagePath });
            }
        }
        res.status(201).json({ message: "Blog created successfully!", blogId });
    } catch (error) {
        console.error("Error creating blog:", error);
        res.status(500).json({ error: "Failed to create blog" });
    }
};

// Update a blog
exports.updateBlog = async (req, res) => {
    const { id, title, slug, content, image, excerpt, status } = req.body;
    try {
        const affectedRows = await Blogs.update({ id, title, slug, content, image, excerpt, status });
        if (affectedRows === 0) {
            return res.status(404).json({ error: "Blog not found or no changes made" });
        }
        res.status(200).json({ message: "Blog updated successfully!" });
    } catch (error) {
        console.error("Error updating blog:", error);
        res.status(500).json({ error: "Failed to update blog" });
    }
};

// Delete a blog
exports.deleteBlog = async (req, res) => {
    const { id } = req.params;
    try {
        const affectedRows = await Blogs.delete(id);
        if (affectedRows === 0) {
            return res.status(404).json({ error: "Blog not found" });
        }
        res.status(200).json({ message: "Blog deleted successfully!" });
    } catch (error) {
        console.error("Error deleting blog:", error);
        res.status(500).json({ error: "Failed to delete blog" });
    }
};
