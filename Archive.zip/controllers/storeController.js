const Store = require('../models/storeModel');
const User = require('../models/userModel'); // If you need to access user details

// Create a new store
exports.createStore = async (req, res) => {
  try {
    // console.log(req.body);
    const {
      userId,
      storeName,
      storeDescription,
      businessName,
      companyRegNumber,
      businessEmail,
      businessNumber,
      businessAddress,
      phoneNumber,
    } = req.body;

    // Access uploaded files
    store_logo = req.files.store_logo ? req.files.store_logo[0].path : '';
    store_banner = req.files.store_banner ? req.files.store_banner[0].path : '';

    // Save the store
    const storeId = await Store.create({
      userId,
      storeName,
      storeDescription,
      store_logo,
      store_banner,
      businessName,
      companyRegNumber,
      businessEmail,
      businessNumber,
      businessAddress,
      phoneNumber
    });
    res.status(201).json({ message: 'Store created successfully', storeId });
  } catch (error) {
    console.error('Error creating store:', error);
    res.status(500).json({ error: error.message });
  }
};

// Get all stores
exports.getStores = async (req, res) => {
  try {
    const stores = await Store.getAllStores();
    res.status(200).json(stores);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a specific store by ID
exports.getStoreById = async (req, res) => {
  try {
    const store = await Store.findById(req.params.id);
    if (!store) {
      return res.status(404).json({ message: 'Store not found' });
    }
    res.status(200).json(store);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get store by user ID (to check if user has a store)
exports.getStoreByUserId = async (req, res) => {
  try {
    const store = await Store.findByUserId(req.params.userId);
    if (!store) {
      return res.status(404).json({ message: 'Store not found for this user' });
    }
    res.status(200).json(store);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update store information
exports.updateStore = async (req, res) => {
  try {
    const storeId = req.params.id;
    const {
      storeName,
      storeDescription,
      storeLogo,
      storeBanner,
      businessName,
      companyRegNumber,
      businessEmail,
      businessAddress,
      phoneNumber,
      email,
      socialPlatforms
    } = req.body;

    // Update the store
    const updated = await Store.update(storeId, {
      storeName,
      storeDescription,
      storeLogo,
      storeBanner,
      businessName,
      companyRegNumber,
      businessEmail,
      businessAddress,
      phoneNumber,
      email,
      socialPlatforms
    });

    if (updated) {
      res.status(200).json({ message: 'Store updated successfully' });
    } else {
      res.status(404).json({ message: 'Store not found' });
    }
  } catch (error) {
    console.error('Error updating store:', error);
    res.status(500).json({ error: error.message });
  }
};

// Delete a store by ID
exports.deleteStore = async (req, res) => {
  try {
    const storeId = req.params.id;
    const deleted = await Store.delete(storeId);

    if (deleted) {
      res.status(200).json({ message: 'Store deleted successfully' });
    } else {
      res.status(404).json({ message: 'Store not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
