const axios = require('axios');
const cheerio = require('cheerio');
const sanitizeHtml = require('sanitize-html');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const sharp = require('sharp');
const imageDownloader = require('image-downloader');
const prompt = require('prompt-sync')(); // Import prompt-sync

const db = require('./config/db'); // Database connection file

// Function to download and process images
async function downloadImage(url, outputPath) {
    try {
        // Download image
        const { filename } = await imageDownloader.image({ url, dest: outputPath });

        // Resize and process the image using Sharp
        await sharp(filename)
            .resize(800) // Resize if necessary
            .toFile(outputPath, (err, info) => {
                if (err) {
                    console.error('Error processing image with Sharp:', err);
                    return;
                }
                console.log('Image processed successfully:', info);
            });
    } catch (error) {
        console.error('Failed to download image:', error.message);
    }
}

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Scraping function to retrieve and save posts
async function scrapePosts(perPage, page) {
    try {
        // Fetch posts from the API using the provided per_page and page
        const response = await axios.get(`https://carservicesltd.com/wp-json/wp/v2/posts?per_page=${perPage}&page=${page}`);
        const posts = response.data;

        for (const post of posts) {
            const { title, content, tags, date } = post;
            const $ = cheerio.load(content.rendered);

            // Sanitize HTML content to remove unnecessary tags and ensure paragraph tags are preserved
            const textContent = sanitizeHtml(content.rendered, {
                allowedTags: ['p', 'b', 'strong', 'i', 'ul', 'ol', 'li', 'br'],
                allowedAttributes: {},
                disallowedTagsMode: 'discard'
            });

            // Set default values for database fields
            const category_id = 1; // Modify as per your category logic
            const user_id = 1; // Modify to use dynamic user ID if needed
            const address = 'Default Address';
            const country = 'Default Country';
            const city = 'Default City';
            const postcode = '00000';
            const phone = '000-000-0000';
            const email = 'default@example.com';
            const website = 'https://example.com';
            const tagString = Array.isArray(tags) ? tags.join(',') : ''; // Convert tags array to comma-separated string

            // Insert post data into the database
            const [result] = await db.query(
                `INSERT INTO posts (title, description, tags, category_id, user_id, address, country, city, postcode, phone, email, website, created_at, updated_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [title.rendered, textContent, tagString, category_id, user_id, address, country, city, postcode, phone, email, website, date, date]
            );

            const postId = result.insertId;
            console.log(`Inserted Post ID: ${postId}`);

            // Process images within the content
            const imagePromises = $('img').map(async (i, img) => {
                const imgUrl = $(img).attr('src');
                if (imgUrl) {
                    const imgFilename = `${uuidv4()}.jpg`; // Unique filename for each image
                    const imgPath = path.join(uploadDir, imgFilename);

                    try {
                        // Download and process the image
                        await downloadImage(imgUrl, imgPath);

                        // Save image data in the database
                        await db.query(
                            `INSERT INTO images (post_id, image_path, created_at) VALUES (?, ?, NOW())`,
                            [postId, `/uploads/${imgFilename}`]
                        );
                        console.log(`Saved image for Post ID ${postId}: ${imgFilename}`);
                    } catch (imgErr) {
                        console.error(`Failed to download image: ${imgUrl}`, imgErr);
                    }
                }
            }).get();

            // Wait for all image processing to complete
            await Promise.all(imagePromises);
        }

        console.log('Scraping completed successfully.');
    } catch (error) {
        console.error('Scraping error:', error.message);
    }
}

// Ask for per_page and page inputs
const perPage = prompt('Enter the number of posts per page: ') || 10; // Default to 10 if no input
const page = prompt('Enter the page number: ') || 1; // Default to page 1 if no input

// Run the scraper function with the user input
scrapePosts(perPage, page);
