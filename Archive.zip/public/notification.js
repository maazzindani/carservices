document.getElementById("sendNotificationForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    
    const token = document.getElementById("token").value;
    const title = document.getElementById("title").value;
    const message = document.getElementById("message").value;

    const response = await fetch("/send-notification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, title, message })
    });

    const result = await response.json();
    document.getElementById("responseMessage").innerText = result.message || "Error sending notification!";
});

document.getElementById("scheduleNotificationForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    
    const token = document.getElementById("scheduleToken").value;
    const title = document.getElementById("scheduleTitle").value;
    const message = document.getElementById("scheduleMessage").value;
    const time = document.getElementById("scheduleTime").value;

    const response = await fetch("/schedule-notification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, title, message, time })
    });

    const result = await response.json();
    document.getElementById("responseMessage").innerText = result.message || "Error scheduling notification!";
});
