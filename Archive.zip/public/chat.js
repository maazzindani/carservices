// const socket = io();


// function setUsername() {
//     const username = document.getElementById("username").value;
//     if (username.trim()) {
//         socket.emit("setUsername", username);
//     }
// }

// function sendMessage() {
//     const messageInput = document.getElementById("messageInput");
//     const message = messageInput.value;
    
//     if (message.trim()) {
//         socket.emit("sendMessage", message);
//         messageInput.value = "";
//     }
// }

// socket.on("receiveMessage", (data) => {
//     const chatMessages = document.getElementById("chat-messages");
//     const messageElement = document.createElement("p");
//     messageElement.innerHTML = `<strong>${data.user}</strong>: ${data.message} <span style="color:gray;font-size:small;">(${data.time})</span>`;
//     chatMessages.appendChild(messageElement);
//     chatMessages.scrollTop = chatMessages.scrollHeight;
// });

// socket.on("userList", (users) => {
//     const userList = document.getElementById("userList");
//     userList.innerHTML = "";
    
//     users.forEach((user) => {
//         const li = document.createElement("li");
//         li.textContent = user;
//         userList.appendChild(li);
//     });
// });
