const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');
const db = require('../config/db');

// Create a business
router.post('/add', upload.single('business_logo'), async (req, res) => {
    try {
        console.log("Hello World");
        console.log(req.body);
        
        const { user_id, business_name, company_reg_number, business_email, business_address, phone_number, website, industry, business_description } = req.body;
        const business_logo = req.file ? req.file.path : null;

        const result = await db.query(`
        INSERT INTO businesses (user_id, business_name, company_reg_number, business_email, business_address, phone_number, website, industry, business_description, business_logo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
      `, [user_id, business_name, company_reg_number, business_email, business_address, phone_number, website, industry, business_description, business_logo]);

        res.status(201).json({ message: 'Business added successfully', businessId: result.insertId });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: error.message });
    }
});

// Get all businesses
router.get('/', async (req, res) => {
    try {
        const businesses = await db.query(`SELECT * FROM businesses`);
        res.status(200).json(businesses);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get a specific business by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const business = await db.query(`SELECT * FROM businesses WHERE id = ?`, [id]);
        if (!business.length) return res.status(404).json({ message: 'Business not found' });
        res.status(200).json(business[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


// Update a business
router.put('/:id', upload.single('business_logo'), async (req, res) => {
    try {
        const { id } = req.params;
        const { business_name, company_reg_number, business_email, business_address, phone_number, website, industry, business_description } = req.body;
        const business_logo = req.file ? req.file.path : null;

        const result = await db.query(`
        UPDATE businesses 
        SET business_name = ?, company_reg_number = ?, business_email = ?, business_address = ?, phone_number = ?, website = ?, industry = ?, business_description = ?, business_logo = COALESCE(?, business_logo)
        WHERE id = ?;
      `, [business_name, company_reg_number, business_email, business_address, phone_number, website, industry, business_description, business_logo, id]);

        if (result.affectedRows === 0) return res.status(404).json({ message: 'Business not found' });
        res.status(200).json({ message: 'Business updated successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});



// Delete a business
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query(`DELETE FROM businesses WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: 'Business not found' });
        res.status(200).json({ message: 'Business deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


module.exports = router;