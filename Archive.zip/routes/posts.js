// routes/posts.js
const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const upload = require('../middleware/upload');


// Route to create a new post
router.post('/add', upload.array('images', 5), postController.createPost);

// Route to get all posts
router.get('/', postController.getPosts);

// Route to get a specific post by ID
router.get('/:id', postController.getPostById);

// Route to get Featured posts
router.get('/featured/posts', postController.getFeaturedPosts);   





module.exports = router;
