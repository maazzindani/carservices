const express = require('express');
const router = express.Router();
const blogController = require('../controllers/blogsController');
const upload = require('../middleware/upload');

router.get("/", blogController.getAllBlogs);
router.get("/:id", blogController.getBlogById);
router.post("/", upload.fields([
    { name: 'image', maxCount: 1 }
]), blogController.createBlog);
router.put("/", blogController.updateBlog);
router.delete("/:id", blogController.deleteBlog);

module.exports = router;
