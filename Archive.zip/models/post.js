// models/Post.js
const db = require('../config/db');

const Post = {
  // Create a new post
  create: async ({
    title, description, tags, category_id, default_category, address,
    country, region, city, postcode, phone, email, website, user_id
  }) => {
    const [result] = await db.query(
      `INSERT INTO posts 
        (title, description, tags, category_id, default_category, address, country, region, city, postcode, phone, email, website, user_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [title, description, tags, category_id, default_category, address, country, region, city, postcode, phone, email, website, user_id]
    );
    return result.insertId;
  },

  // Find all posts with pagination, search, and location filters
  findAll: async ({ page = 1, limit = 10, search = '', location = '' }) => {
    page = parseInt(page) || 1;
    limit = parseInt(limit) || 10;
    const offset = (page - 1) * limit;

    // Fetch posts with search and location filters
    console.log(`Page: ${page}, Limit: ${limit}, Offset: ${offset}`);
    const [posts] = await db.query(
      'SELECT * FROM posts WHERE title LIKE ? AND address LIKE ? LIMIT ? OFFSET ?',
      [`%${search}%`, `%${location}%`, limit, offset]
    );

    return posts;
  },

  // Count the total number of posts with filters applied
  count: async ({ search = '', location = '' }) => {
    const [result] = await db.query(
      'SELECT COUNT(*) AS total FROM posts WHERE title LIKE ? AND address LIKE ?',
      [`%${search}%`, `%${location}%`]
    );
    return result[0].total;
  },

  // Find all Featured posts with pagination, search, and location filters
  findFeaturedPosts: async ({ page = 1, limit = 10, search = '', location = '' }) => {
    page = parseInt(page) || 1; // Ensure page is a valid number
    limit = parseInt(limit) || 10; // Ensure limit is a valid number
    const offset = (page - 1) * limit; // Calculate the offset for pagination

    // Fetch featured posts with search and location filters
    console.log('SELECT * FROM posts WHERE featured = 1 AND title LIKE ? AND address LIKE ? LIMIT ? OFFSET ?',
      [`%${search}%`, `%${location}%`, limit, offset]);
    let [posts] = await db.query(
      'SELECT * FROM posts WHERE featured = 1 AND title LIKE ? AND address LIKE ? LIMIT ? OFFSET ?',
      [`%${search}%`, `%${location}%`, limit, offset]
    );

    // If no featured posts found, fetch all posts
    if (posts.length === 0) {
      console.log('SELECT * FROM posts WHERE title LIKE ? AND address LIKE ? LIMIT ? OFFSET ?',
        [`%${search}%`, `%${location}%`, limit, offset]);
      [posts] = await db.query(
        'SELECT * FROM posts WHERE title LIKE ? AND address LIKE ? LIMIT ? OFFSET ?',
        [`%${search}%`, `%${location}%`, limit, offset]
      );
    }

    return posts;
  },

  // Count the total number of posts (featured if available, or all posts)
  countFeaturedPosts: async ({ search = '', location = '' }) => {
    // Count featured posts with search and location filters
    console.log('SELECT COUNT(*) AS total FROM posts WHERE featured = 1 AND title LIKE ? AND address LIKE ?',
      [`%${search}%`, `%${location}%`]);
    const [featuredCount] = await db.query(
      'SELECT COUNT(*) AS total FROM posts WHERE featured = 1 AND title LIKE ? AND address LIKE ?',
      [`%${search}%`, `%${location}%`]
    );

    if (featuredCount[0].total > 0) {
      return featuredCount[0].total;  // If there are featured posts, return their count
    }

    // If no featured posts, count all posts with search and location filters
    console.log('SELECT COUNT(*) AS total FROM posts WHERE title LIKE ? AND address LIKE ?',
      [`%${search}%`, `%${location}%`]);
    const [totalCount] = await db.query(
      'SELECT COUNT(*) AS total FROM posts WHERE title LIKE ? AND address LIKE ?',
      [`%${search}%`, `%${location}%`]
    );

    return totalCount[0].total;  // Return the count of all posts if no featured posts
  },



  // Find all Sorted Featured posts
  findSortedFeaturedPosts: async (id) => {
    const [rows] = await db.query('SELECT * FROM posts WHERE featured = 1 AND category_id = ?', [id]);
    return rows;
  },

  // Find a post by ID
  findById: async (id) => {
    const [rows] = await db.query('SELECT * FROM posts WHERE id = ?', [id]);
    return rows[0];
  },
};

module.exports = Post;
