const db = require('../config/db'); // Import database connection

const Blogs = {

    // Find all blogs with pagination, search, and location filters
    findAll: async ({ page = 1, limit = 10, search = '', offset = 0 }) => {
        page = parseInt(page) || 1;
        limit = parseInt(limit) || 10;

        // Fetch blogs with search and location filters
        console.log(`Page: ${page}, Limit: ${limit}, Offset: ${offset}`);
        const [blogs] = await db.query(
            'SELECT * FROM blogs WHERE title LIKE ? LIMIT ? OFFSET ?',
            [`%${search}%`, limit, offset]
        );

        return blogs;
    },

    // Count the total number of blogs with filters applied
    count: async ({ search = ''}) => {
        const [result] = await db.query(
            'SELECT COUNT(*) AS total FROM blogs WHERE title LIKE ?',
            [`%${search}%`]
        );
        return result[0].total;
    },


    getAll: async () => {
        const [rows] = await db.query('SELECT * FROM blogs');
        return rows;
    },

    findById: async (id) => {
        const [rows] = await db.query('SELECT * FROM blogs WHERE id = ?', [id]);
        return rows[0];
    },

    create: async ({ user_id, title, slug, content, image, excerpt, status }) => {
        const query = `
        INSERT INTO blogs (user_id, title, slug, content, excerpt, status)
        VALUES (?, ?, ?, ?, ?, ?)
    `;
        const values = [user_id, title, slug, content, excerpt, status];

        console.log("Executing SQL query:");
        console.log(query);  // Print the query string
        console.log("With values:");
        console.log(values); // Print the values
        const [result] = await db.query(
            `INSERT INTO blogs (user_id, title, slug, content, excerpt, status)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [user_id, title, slug, content, excerpt, status]
        );
        return result.insertId;
    },

    update: async ({ id, title, slug, content, image, excerpt, status }) => {
        const [result] = await db.query(
            `UPDATE blogs SET title = ?, slug = ?, content = ?, image = ?, excerpt = ?, status = ? 
             WHERE id = ?`,
            [title, slug, content, image, excerpt, status, id]
        );
        return result.affectedRows;
    },

    delete: async (id) => {
        const [result] = await db.query('DELETE FROM blogs WHERE id = ?', [id]);
        return result.affectedRows;
    },
    findBySlug: async (slug) => {  // New method: findBySlug
        const [rows] = await db.query('SELECT * FROM blogs WHERE slug = ?', [slug]);
        return rows[0]; // Returns the first matching blog or undefined if none found
    },

    // Or a more generic findOne if you want to search by other fields too:
    findOne: async (field, value) => {
        const [rows] = await db.query(`SELECT * FROM blogs WHERE ${field} = ?`, [value]);
        return rows[0];
    },

};

module.exports = Blogs;
