const db = require('../config/db');
const bcrypt = require('bcrypt');

const User = {
  // Create a new user
  create: async ({ name, mobile, dob, address, email, password, isAdmin = false }) => {
    const hashedPassword = await bcrypt.hash(password, 10);
      // Prepare the SQL query and parameters
      const sqlQuery = 'INSERT INTO users (name, mobile_number, date_of_birth, physical_address, email, password, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?)';
      const queryParams = [name, mobile, dob, address, email, hashedPassword, isAdmin];
  
      // Log the query and parameters
      console.log('Executing SQL query:', sqlQuery);
      console.log('With parameters:', queryParams);
    // Execute the query
    const [result] = await db.query(sqlQuery, queryParams);
    return result.insertId;
  },

  // Find user by email
  findByEmail: async (email) => {
    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  },

  // Get all users (example for admin access)
  findAll: async () => {
    const [rows] = await db.query('SELECT * FROM users');
    return rows;
  },

  // Get all users (example for admin access)
  findAllDevices: async () => {
    const [rows] = await db.query('SELECT * FROM devices');
    return rows;
  },


  // Find user by ID
  findById: async (id) => {
    const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [id]);
    return rows[0]; // Returns the user if found, otherwise returns undefined
  },
};


module.exports = User;
