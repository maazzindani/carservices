// models/Image.js
const db = require('../config/db');

const BlogsImage = {
  // Add a new image
  create: async ({ blog_id, image_path }) => {
    const [result] = await db.query(
      `INSERT INTO blogs_images (blog_id, image_path) VALUES (?, ?)`,
      [blog_id, image_path]
    );
    return result.insertId;
  },

  // Find all images associated with a post
  findByPostId: async (post_id) => {
    const [rows] = await db.query('SELECT * FROM blog_id WHERE blog_id = ?', [post_id]);
    return rows;
  },
};

module.exports = BlogsImage;
