const express = require('express');
const dotenv = require('dotenv');
const authRoutes = require('./routes/authRoutes'); // Import authRoutes
const subscriptionRoutes = require('./routes/subscriptionRoutes'); // Import subscriptionRoutes
const postRoutes = require('./routes/posts');
const categoryRoutes = require('./routes/categoryRoutes');
const userRoutes = require('./routes/userRoutes');
const postController = require('./controllers/postController');
const trafficAlertRoutes = require('./routes/trafficalertsRoutes');
const storeRoutes = require('./routes/storeRoutes');
const reminderRoutes = require("./routes/reminderRoutes");
const businessRoutes = require("./routes/businessRoutes");
const blogRoutes = require("./routes/blogsRoutes");
const i18n = require('i18n');
const admin = require('firebase-admin');
const path = require('path');
const db = require('./config/db');
const cookieParser = require('cookie-parser');
const cron = require("node-cron");



// Load environment variables
dotenv.config();

// Configure i18n
i18n.configure({
  locales: ['en', 'es', 'fr', 'arab', 'ch', 'pak', 'ind', 'dutch', 'german', 'italian', 'portugueese'], // Supported languages, add more as needed
  directory: __dirname + '/locales', // Path to language files
  defaultLocale: 'fr',
  cookie: 'lang', // To remember the language setting in cookies
  autoReload: true,
  syncFiles: true,
});



// Initialize Firebase Admin SDK
const serviceAccount = path.join(__dirname, 'carservicesltd-806bf-firebase-adminsdk-fbsvc-8a35f68d2d.json'); // Your service account JSON file path


admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});




const app = express();

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files from the "public" folder
app.use(express.static('public'));

// Serve static files from the "uploads" folder
app.use('/uploads', express.static('uploads')); // <-- Added to serve images from uploads

// Middleware
app.use(express.json());

// Use cookie parser middleware
app.use(cookieParser());

// Middleware to set locale based on cookie
app.use((req, res, next) => {
  let lang = req.cookies.lang || 'en';
  i18n.setLocale(req, lang);
  res.locals.__ = res.__; // Make translation function available in views
  next();
});


app.use(i18n.init);

// Route for the homepage
app.get('/', (req, res) => {
  res.render('index', { title: 'Car Services Ltd' });
});

// Initialize i18n
app.use(i18n.init);

app.get('/change-language/:lang', (req, res) => {
  console.log('Changing language to:', req.params.lang); // Debug line
  res.cookie('lang', req.params.lang); // Store language in a cookie
  res.setLocale(req.params.lang);
  res.redirect('back'); // Redirect back to the previous page
});



app.get('/blog', async (req, res) => {
  try {
    const page = req.query.page || 1; // Default to 1 if no page query
    const limit = req.query.limit || 10; // Default to 10 if no limit query
    const serverUrl = `${req.protocol}://${req.get('host')}/api/blogs?page=${page}&limit=${limit}`; // Use query params in URL
    const response = await fetch(serverUrl);
    const blogsList = await response.json();

    // Shorten the descriptions and add Read More links
    const maxLength = 200; // Maximum length for description

    const blogsWithShortDescriptions = blogsList.blogs.map(blog => {
      let shortDescription = blog.content;
      let readMoreLink = '';

      // If content exceeds max length, truncate and add "Read More"
      if (blog.content.length > maxLength) {
        shortDescription = blog.content.substring(0, maxLength) + '...';
        readMoreLink = `<a href="/blog/${blog.id}" class="read-more">Read More</a>`; // Link to full blog post
      }

      return {
        ...blog,
        shortDescription: shortDescription,
        readMoreLink: readMoreLink
      };
    });

    // Render the blogs page with pagination and shortened descriptions
    res.render('blog', {
      title: 'Car Services Ltd',
      blogs: {
        ...blogsList,
        blogs: blogsWithShortDescriptions // Use the modified blogs array with shortened descriptions
      },
      currentPage: blogsList.currentPage,
      totalPages: blogsList.totalPages,
      totalBlogs: blogsList.totalBlogs,
      limit: limit
    });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});



app.get('/search', async (req, res) => {
  // Fetch all posts
  try {
    const page = req.query.page || 1; // Get page from query params, default to 1
    const limit = req.query.limit || 10; // Get limit from query params, default to 10
    // Call the /api/posts route to get posts
    const serverUrl = `${req.protocol}://${req.get('host')}/api/posts?page=${page}&limit=${limit}`; // Include query params in URL

    const response = await fetch(serverUrl);

    const postList = await response.json();
    const posts = postList;
    const postsWithShortDescriptions = posts.posts.map(post => {
      const maxLength = 200; // Adjust as needed
      let shortDescription = post.description;
      let readMoreLink = '';

      if (post.description.length > maxLength) {
        shortDescription = post.description.substring(0, maxLength) + '...';
        readMoreLink = `<a href="/post/${post.id}" class="read-more">Read More</a>`; // Link to the full post details page
      }
      return {
        ...post,
        shortDescription: shortDescription,  // Add the shortened description
        readMoreLink: readMoreLink          // Add the "Read More" link HTML
      };
    });

    res.render('search', {
      title: 'Car Services Ltd', posts: {
        ...posts, // Spread the other properties of the posts object
        posts: postsWithShortDescriptions // Use the modified posts array
      }, currentPage: posts.currentPage, totalPages: posts.totalPages,
      totalPosts: posts.totalPosts,
      limit: 10
    });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});

app.get('/post-add', (req, res) => {
  res.render('post_an_add', { title: 'Car Services Ltd' });
});

// Route to get Sorted Featured posts
app.get('/featured/sorted', async (req, res) => {
  // Fetch all posts
  try {
    const page = req.query.page || 1; // Get page from query params, default to 1
    const limit = req.query.limit || 10; // Get limit from query params, default to 10
    // Call the /api/postnps route to get posts
    const serverUrl = `${req.protocol}://${req.get('host')}/api/posts/featured?page=${page}&limit=${limit}`; // Include query params in URL

    const response = await fetch(serverUrl);

    const posts = await response.json();
    // console.log("Posts with images:", posts); // Add this line to verify data structure
    console.log(posts);
    // return posts;
    res.status(200).json(posts);
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});


app.get('/post-blog', async (req, res) => {
  try {
    res.render('post_a_blog', { title: 'Car Services Ltd' });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});


app.get('/featured-posts', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 2;
    console.log(`${req.protocol}://${req.get('host')}/api/posts/featured/posts?page=${page}&limit=${limit}`);
    const serverUrl = `${req.protocol}://${req.get('host')}/api/posts/featured/posts?page=${page}&limit=${limit}`;
    const response = await fetch(serverUrl);

    const postList = await response.json();
    const posts = postList.posts;

    // Calculate pagination details
    const totalPosts = postList.totalCount;  // Assume the API sends this
    const totalPages = Math.ceil(totalPosts / limit);

    const postsWithShortDescriptions = posts.map(post => {
      const maxLength = 200;
      let shortDescription = post.description;
      let readMoreLink = '';
      if (post.description.length > maxLength) {
        shortDescription = post.description.substring(0, maxLength) + '...';
        readMoreLink = `<a href="/post/${post.id}" class="read-more">Read More</a>`;
      }
      return {
        ...post,
        shortDescription,
        readMoreLink
      };
    });

    // Send pagination data along with posts
    res.render('featured_posts', { 
      title: 'Car Services Ltd', 
      posts: postsWithShortDescriptions, 
      totalPages, 
      currentPage: page
    });

  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});


app.get('/promoted-posts', async (req, res) => {
  // Fetch all posts
  try {
    const posts = await postController.getFeaturedPosts(); // Get all posts
    // console.log("Posts with images:", posts); // Add this line to verify data structure
    console.log(posts);
    res.render('promoted_posts', { title: 'Car Services Ltd', posts });
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
});

app.get('/car-valuation', (req, res) => {
  res.render('calculators/car_valuation_calculator', { title: 'Car Services Ltd' });
});

app.get('/car-finance', (req, res) => {
  res.render('calculators/car_finance_calulator', { title: 'Car Services Ltd' });
});

app.get('/car-depreciation', (req, res) => {
  res.render('calculators/car_depreciation_calculator', { title: 'Car Services Ltd' });
});

app.get('/car-insurance-cost-calculator', (req, res) => {
  res.render('calculators/car_insurance_cost_calculator', { title: 'Car Services Ltd' });
});

app.get('/car-loan-calculator', (req, res) => {
  res.render('calculators/car_loan_calculator', { title: 'Car Services Ltd' });
});

app.get('/mileage-tax-calculator', (req, res) => {
  res.render('calculators/mileage_calculator', { title: 'Car Services Ltd' });
});

app.get('/fuel-efficiancy-calculator', (req, res) => {
  res.render('calculators/fuel_efficiency_calculator', { title: 'Car Services Ltd' });
});

app.get('/mileage-claim-calculator', (req, res) => {
  res.render('calculators/mileage_claim_calculator', { title: 'Car Services Ltd' });
});

app.get('/route-planner', (req, res) => {
  res.render('calculators/hgv_route_planner', { title: 'Car Services Ltd' });
});

app.get('/fuel-cost-calculator', (req, res) => {
  res.render('calculators/fuel_cost_calculator', { title: 'Car Services Ltd' });
});

app.get('/calculators', (req, res) => {
  res.render('calculators/select_calculator', { title: 'Car Services Ltd' });
});


app.get('/subscription', (req, res) => {
  res.render('subscription/subscription', { title: 'Car Services Ltd' });
});


app.get('/about', (req, res) => {
  res.render('about', { title: 'Car Services Ltd' });
});

app.get('/contact', (req, res) => {
  res.render('contact', { title: 'Car Services Ltd' });
});

app.get('/careers', (req, res) => {
  res.render('careers', { title: 'Car Services Ltd' });
});


app.get('/forum', (req, res) => {
  res.render('forum', { title: 'Car Services Ltd' });
});


app.get('/affiliate', (req, res) => {
  res.render('affiliate', { title: 'Car Services Ltd' });
});

app.get('/terms-of-use', (req, res) => {
  res.render('terms-of-use', { title: 'Car Services Ltd' });
});

app.get('/privacy-policy', (req, res) => {
  res.render('privacy-policy', { title: 'Car Services Ltd' });
});

app.get('/disclaimer', (req, res) => {
  res.render('disclaimer', { title: 'Car Services Ltd' });
});

app.get('/user-guide', (req, res) => {
  res.render('user-guide', { title: 'Car Services Ltd' });
});


app.get('/postTrafficAlert', (req, res) => {
  res.render('post_traffic_alert', { title: 'Car Services Ltd' });
});

app.get('/postStore', (req, res) => {
  res.render('post_store', { title: 'Car Services Ltd' });
});

app.get('/stores', (req, res) => {
  res.render('stores_list', { title: 'Car Services Ltd' });
});

app.get('/traffic-alerts', (req, res) => {
  res.render('traffic_alerts', { title: 'Car Services Ltd' });
});

app.get('/features', (req, res) => {
  res.render('features_page', { title: 'Car Services Ltd' });
});




// Define Routes
app.get('/service-due-reminder', async (req, res) => {
  try {
    // Fetch service due reminder details or render the appropriate page
    res.render('service-due-reminder'); // render service-due-reminder.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.get('/insurance-reminder', async (req, res) => {
  try {
    res.render('insurance-reminder'); // render insurance-reminder.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.get('/road-tax-reminder', async (req, res) => {
  try {
    res.render('road-tax-reminder'); // render road-tax-reminder.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.get('/basic-support', async (req, res) => {
  try {
    res.render('basic-support'); // render basic-support.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.get('/map-service', async (req, res) => {
  try {
    res.render('map-service'); // render map-service.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.get('/chat-support', async (req, res) => {
  try {
    res.render('chat_page'); // render map-service.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.get('/post-business', async (req, res) => {
  try {
    // Fetch service due reminder details or render the appropriate page
    res.render('post_a_business'); // render service-due-reminder.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});


app.get('/business', async (req, res) => {
  try {
    // Fetch service due reminder details or render the appropriate page
    res.render('businesses_list_page'); // render service-due-reminder.ejs
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

// API routes
app.use('/api/auth', authRoutes); // Use authRoutes for login
app.use('/api/posts', postRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/users', userRoutes);
app.use('/api/trafficAlerts', trafficAlertRoutes);
app.use('/api/storeRoutes', storeRoutes);
app.use('/api/subscriptions', subscriptionRoutes); // Use subscriptionRoutes for subscription data
app.use("/api/reminders", reminderRoutes); // Reminders
app.use("/api/business", businessRoutes); // Business
app.use("/api/blogs", blogRoutes); // Blogs





// Push Notifications

// Function to send notifications
const sendNotification = async (token, title, message) => {
  const payload = {
    notification: {
      title,
      body: message,
    },
  };

  try {
    await admin.messaging().send({ token, ...payload });
    console.log("Notification sent successfully!");
  } catch (error) {
    console.error("Error sending notification:", error);
  }
};


// API Route to Send Notification
app.post("/send-notification", async (req, res) => {
  const { title, message } = req.body;
  console.log(req.body);
  // if (!title || !message) {
  //   return res.status(400).json({ error: "Missing required fields" });
  // }

  try {

    // Fetch all device tokens from the database
    const [devices] = await db.query("SELECT device_uid FROM devices");

    if (!devices.length) {
      return res.status(404).json({ error: "No devices found" });
    }

    // Send notification to all devices
    for (const device of devices) {
      await sendNotification(device.device_uid, title, message);
    }
    res.status(200).json({ success: true, message: "Notifications sent to all devices" });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});


// API Route to Schedule Notification
app.post("/schedule-notification", (req, res) => {
  const { token, title, message, time } = req.body;

  // if (!token || !title || !message || !time) {
  //   return res.status(400).json({ error: "Missing required fields" });
  // }

  // Schedule notification using node-cron (time format: "*/5 * * * *" for every 5 minutes)
  cron.schedule(time, () => {
    sendNotification(token, title, message);
    console.log(`Scheduled Notification Sent at ${time}`);
  });

  res.status(200).json({ success: true, message: `Notification scheduled at ${time}` });
});





// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
