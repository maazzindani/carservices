const trafficAlertController = require('../controllers/trafficAlertController');
const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');

// Traffic Alerts Routes
router.get('/alerts', trafficAlertController.getAllAlerts);
router.get('/alerts/:id', trafficAlertController.getAlertById);
router.post('/alerts', upload.array('images', 5), trafficAlertController.createAlert);
router.put('/alerts/:id', trafficAlertController.updateAlert);
router.delete('/alerts/:id', trafficAlertController.deleteAlert);

module.exports = router;
