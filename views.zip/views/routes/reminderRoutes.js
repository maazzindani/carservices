const express = require('express');
const router = express.Router();
const reminderController = require('../controllers/remindersControllers');


router.get("/service/:userId", reminderController.getServiceReminders);
router.get("/insurance/:userId", reminderController.getInsuranceReminders);
router.get("/road-tax/:userId", reminderController.getRoadTaxReminders);

router.post("/service", reminderController.createServiceReminder);
router.post("/insurance", reminderController.createInsuranceReminder);
router.post("/road-tax", reminderController.createRoadTaxReminder);

router.put("/service", reminderController.updateServiceReminder);
router.put("/insurance", reminderController.updateInsuranceReminder);
router.put("/road-tax", reminderController.updateRoadTaxReminder);

router.delete("/service/:id", reminderController.deleteServiceReminder);
router.delete("/insurance/:id", reminderController.deleteInsuranceReminder);
router.delete("/road-tax/:id", reminderController.deleteRoadTaxReminder);

module.exports = router;

module.exports = router;