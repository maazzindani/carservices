const mysql = require('mysql2/promise');
const axios = require('axios'); // Import axios for fetching public IP

require('dotenv').config();

// Function to fetch and print public IP
const fetchPublicIP = async () => {
  try {
    const response = await axios.get('https://api64.ipify.org?format=json'); // Fetch public IP
    const publicIP = response.data.ip;
    console.log(`Your public IP is: ${publicIP}`);
    return publicIP;
  } catch (error) {
    console.error('Error fetching public IP:', error.message);
    throw error;
  }
};

const db = mysql.createPool({
  host: '192.250.229.33',
  user: 'apnabusiness_new',
  password: 'q${NT9VtOYY0',
  database: 'apnabusiness_carservices',
  port: 3306
});

// Print public IP and initialize database connection
(async () => {
  await fetchPublicIP(); // Fetch and log the public IP
  console.log('Database configuration ready!');
})();

module.exports = db;
