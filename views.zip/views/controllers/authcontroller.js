const User = require('../models/userModel');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

// Signup function 
exports.signup = async (req, res) => {
  const { name, mobile, dob, address, email, password, isAdmin } = req.body;
  try {
    console.log({ name, mobile, dob, address, email, password, isAdmin });
    const userExists = await User.findByEmail(email);
    if (userExists) return res.status(400).json({ message: 'Email already registered' });
    const userId = await User.create({ name, mobile, dob, address, email, password, isAdmin });
    res.status(201).json({ message: 'User created', userId });
  } catch (error) {
    console.log(error);
    
    res.status(500).json({ message: 'Error signing up' });
  }
};

// Login function
exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findByEmail(email);
    if (!user) return res.status(400).json({ message: 'Invalid email or password' });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(400).json({ message: 'Invalid email or password' });

    const token = jwt.sign({ id: user.id, isAdmin: user.is_admin }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });
    console.log(token);
    res.json({ message: 'Login successful', token , user:user});
  } catch (error) {
    res.status(500).json({ message: 'Error logging in' });
  }
};
