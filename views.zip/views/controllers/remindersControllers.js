const db = require("../config/db");

// ---------------------- GET REMINDERS ----------------------

// Get all Service Reminders for a User
exports.getServiceReminders = async (req, res) => {
    const userId = req.params.userId;
    try {
        const [reminders] = await db.query(
            `SELECT * FROM service_reminders WHERE user_id = ?`, [userId]
        );
        res.status(200).json(reminders);
    } catch (error) {
        console.error("Error fetching service reminders:", error);
        res.status(500).json({ error: "Failed to fetch service reminders" });
    }
};

// Get all Insurance Reminders for a User
exports.getInsuranceReminders = async (req, res) => {
    const userId = req.params.userId;
    try {
        const [reminders] = await db.query(
            `SELECT * FROM insurance_reminders WHERE user_id = ?`, [userId]
        );
        res.status(200).json(reminders);
    } catch (error) {
        console.error("Error fetching insurance reminders:", error);
        res.status(500).json({ error: "Failed to fetch insurance reminders" });
    }
};

// Get all Road Tax Reminders for a User
exports.getRoadTaxReminders = async (req, res) => {
    const userId = req.params.userId;
    try {
        const [reminders] = await db.query(
            `SELECT * FROM road_tax_reminders WHERE user_id = ?`, [userId]
        );
        res.status(200).json(reminders);
    } catch (error) {
        console.error("Error fetching road tax reminders:", error);
        res.status(500).json({ error: "Failed to fetch road tax reminders" });
    }
};

// ---------------------- CREATE REMINDERS ----------------------

// Create a Service Reminder
exports.createServiceReminder = async (req, res) => {
    const { user_id, reminder_date, message } = req.body;
    try {
        await db.query(
            `INSERT INTO service_reminders (user_id, reminder_date, message) VALUES (?, ?, ?)`,
            [user_id, reminder_date, message]
        );
        res.status(201).json({ message: "Service reminder added successfully!" });
    } catch (error) {
        console.error("Error creating service reminder:", error);
        res.status(500).json({ error: "Failed to create service reminder" });
    }
};

// Create an Insurance Reminder
exports.createInsuranceReminder = async (req, res) => {
    const { user_id, reminder_date, message } = req.body;
    try {
        await db.query(
            `INSERT INTO insurance_reminders (user_id, reminder_date, message) VALUES (?, ?, ?)`,
            [user_id, reminder_date, message]
        );
        res.status(201).json({ message: "Insurance reminder added successfully!" });
    } catch (error) {
        console.error("Error creating insurance reminder:", error);
        res.status(500).json({ error: "Failed to create insurance reminder" });
    }
};

// Create a Road Tax Reminder
exports.createRoadTaxReminder = async (req, res) => {
    const { user_id, reminder_date, message } = req.body;
    try {
        await db.query(
            `INSERT INTO road_tax_reminders (user_id, reminder_date, message) VALUES (?, ?, ?)`,
            [user_id, reminder_date, message]
        );
        res.status(201).json({ message: "Road tax reminder added successfully!" });
    } catch (error) {
        console.error("Error creating road tax reminder:", error);
        res.status(500).json({ error: "Failed to create road tax reminder" });
    }
};

// ---------------------- UPDATE REMINDERS ----------------------

// Update a Service Reminder
exports.updateServiceReminder = async (req, res) => {
    const { id, reminder_date, message } = req.body;
    try {
        await db.query(
            `UPDATE service_reminders SET reminder_date = ?, message = ? WHERE id = ?`,
            [reminder_date, message, id]
        );
        res.status(200).json({ message: "Service reminder updated successfully!" });
    } catch (error) {
        console.error("Error updating service reminder:", error);
        res.status(500).json({ error: "Failed to update service reminder" });
    }
};

// Update an Insurance Reminder
exports.updateInsuranceReminder = async (req, res) => {
    const { id, reminder_date, message } = req.body;
    try {
        await db.query(
            `UPDATE insurance_reminders SET reminder_date = ?, message = ? WHERE id = ?`,
            [reminder_date, message, id]
        );
        res.status(200).json({ message: "Insurance reminder updated successfully!" });
    } catch (error) {
        console.error("Error updating insurance reminder:", error);
        res.status(500).json({ error: "Failed to update insurance reminder" });
    }
};

// Update a Road Tax Reminder
exports.updateRoadTaxReminder = async (req, res) => {
    const { id, reminder_date, message } = req.body;
    try {
        await db.query(
            `UPDATE road_tax_reminders SET reminder_date = ?, message = ? WHERE id = ?`,
            [reminder_date, message, id]
        );
        res.status(200).json({ message: "Road tax reminder updated successfully!" });
    } catch (error) {
        console.error("Error updating road tax reminder:", error);
        res.status(500).json({ error: "Failed to update road tax reminder" });
    }
};

// ---------------------- DELETE REMINDERS ----------------------

// Delete a Service Reminder
exports.deleteServiceReminder = async (req, res) => {
    const { id } = req.params;
    try {
        await db.query(`DELETE FROM service_reminders WHERE id = ?`, [id]);
        res.status(200).json({ message: "Service reminder deleted successfully!" });
    } catch (error) {
        console.error("Error deleting service reminder:", error);
        res.status(500).json({ error: "Failed to delete service reminder" });
    }
};

// Delete an Insurance Reminder
exports.deleteInsuranceReminder = async (req, res) => {
    const { id } = req.params;
    try {
        await db.query(`DELETE FROM insurance_reminders WHERE id = ?`, [id]);
        res.status(200).json({ message: "Insurance reminder deleted successfully!" });
    } catch (error) {
        console.error("Error deleting insurance reminder:", error);
        res.status(500).json({ error: "Failed to delete insurance reminder" });
    }
};

// Delete a Road Tax Reminder
exports.deleteRoadTaxReminder = async (req, res) => {
    const { id } = req.params;
    try {
        await db.query(`DELETE FROM road_tax_reminders WHERE id = ?`, [id]);
        res.status(200).json({ message: "Road tax reminder deleted successfully!" });
    } catch (error) {
        console.error("Error deleting road tax reminder:", error);
        res.status(500).json({ error: "Failed to delete road tax reminder" });
    }
};
