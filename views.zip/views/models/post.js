// models/Post.js
const db = require('../config/db');

const Post = {
  // Create a new post
  create: async ({
    title, description, tags, category_id, default_category, address,
    country, region, city, postcode, phone, email, website, user_id
  }) => {
    const [result] = await db.query(
      `INSERT INTO posts 
        (title, description, tags, category_id, default_category, address, country, region, city, postcode, phone, email, website, user_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [title, description, tags, category_id, default_category, address, country, region, city, postcode, phone, email, website, user_id]
    );
    return result.insertId;
  },

  // Find all posts
  findAll: async () => {
    const [rows] = await db.query('SELECT * FROM posts');
    return rows;
  },

  // Find all Featured posts
  findFeaturedPosts: async () => {
    const [rows] = await db.query('SELECT * FROM posts WHERE featured = 1');


    console.log([rows])
    return rows;
  },

  // Find all Sorted Featured posts
  findSortedFeaturedPosts: async (id) => {
    const [rows] = await db.query('SELECT * FROM posts WHERE featured = 1 AND category_id = ?', [id]);
    return rows;
  },

  // Find a post by ID
  findById: async (id) => {
    const [rows] = await db.query('SELECT * FROM posts WHERE id = ?', [id]);
    return rows[0];
  },
};

module.exports = Post;
