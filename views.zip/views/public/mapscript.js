let map;
let directionsService;
let directionsRenderer;
let userMarker;

function initMap() {
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 37.7749, lng: -122.4194 }, // Default: San Francisco
        zoom: 12,
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(map);
    directionsRenderer.setPanel(document.getElementById("directionsPanel"));

    getUserLocation();
}

// 🛣️ Calculate Route with Selected Travel Mode & Waypoints
function calculateRoute() {
    const startLocation = document.getElementById("startLocation").value;
    const endLocation = document.getElementById("endLocation").value;
    const travelMode = document.getElementById("travelMode").value;
    const waypointsInput = document.getElementById("waypoints").value;

    if (!startLocation || !endLocation) {
        alert("Please enter both starting location and destination.");
        return;
    }

    let waypoints = [];
    if (waypointsInput) {
        waypoints = waypointsInput.split(",").map((point) => ({
            location: point.trim(),
            stopover: true,
        }));
    }

    const request = {
        origin: startLocation,
        destination: endLocation,
        waypoints: waypoints,
        travelMode: google.maps.TravelMode[travelMode.toUpperCase()],
    };

    directionsService.route(request, (result, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
            directionsRenderer.setDirections(result);
        } else {
            alert("Could not get directions: " + status);
        }
    });
}

// 📍 Get User's Live Location
function getUserLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const userPos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                };

                userMarker = new google.maps.Marker({
                    position: userPos,
                    map: map,
                    title: "You are here",
                    icon: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                });

                map.setCenter(userPos);
            },
            () => {
                alert("Geolocation failed. Please enter your location manually.");
            }
        );
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

// 🔍 Find Nearby Services (Hospitals, Gas Stations, Restaurants)
function findNearby(type) {
    const service = new google.maps.places.PlacesService(map);
    service.nearbySearch(
        {
            location: map.getCenter(),
            radius: 5000,
            type: type,
        },
        (results, status) => {
            if (status === google.maps.places.PlacesServiceStatus.OK) {
                results.forEach((place) => {
                    new google.maps.Marker({
                        position: place.geometry.location,
                        map: map,
                        title: place.name,
                    });
                });
            } else {
                alert("No nearby " + type + " found.");
            }
        }
    );
}

window.onload = initMap;
