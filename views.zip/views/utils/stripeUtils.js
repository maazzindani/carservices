const stripe = require('../config/stripeConfig');

exports.createCustomer = async (email, paymentMethodId) => {
  return await stripe.customers.create({
    email,
    payment_method: paymentMethodId,
    invoice_settings: { default_payment_method: paymentMethodId }
  });
};
