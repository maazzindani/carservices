// models/Image.js
const db = require('../config/db');

const Image = {
  // Add a new image
  create: async ({ post_id, image_path }) => {
    const [result] = await db.query(
      `INSERT INTO images (post_id, image_path) VALUES (?, ?)`,
      [post_id, image_path]
    );
    return result.insertId;
  },

  // Find all images associated with a post
  findByPostId: async (post_id) => {
    const [rows] = await db.query('SELECT * FROM images WHERE post_id = ?', [post_id]);
    return rows;
  },
};

module.exports = Image;
