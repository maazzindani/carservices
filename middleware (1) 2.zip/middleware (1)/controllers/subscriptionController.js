const Subscription = require('../models/subscriptionModel');
// const { client } = require('../config/paypal');
// const paypal = require('@paypal/checkout-server-sdk');
const db = require('../config/db');


// Get all available subscriptions
exports.getSubscriptions = async (req, res) => {
  try {
    const subscriptions = await Subscription.findAll();
    res.status(200).json(subscriptions);
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    res.status(500).json({ error: 'Failed to fetch subscriptions' });
  }
};

// Subscribe a user to a plan
exports.subscribe = async (req, res) => {
  const { userId, planId } = req.body;

  try {
    // Create a PayPal subscription
    const subscriber = {
      name: req.user?.name || 'Anonymous',
      email_address: req.user?.email || 'no-email@example.com'
    };

    const subscriptionDetails = await Subscription.createPayPalSubscription({ planId, subscriber });

    // Save subscription details to the database
    const subscriptionId = await Subscription.create({
      userId,
      paypalSubscriptionId: subscriptionDetails.subscriptionId,
      expiresAt: new Date(subscriptionDetails.expiresAt),
      status: subscriptionDetails.status
    });

    res.status(201).json({ message: 'Subscription successful', subscriptionDetails });
  } catch (error) {
    console.error('Error creating subscription:', error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
};

// Cancel a subscription
exports.cancelSubscription = async (req, res) => {
  const { paypalSubscriptionId } = req.body;

  try {
    // Cancel subscription on PayPal
    const isCancelled = await Subscription.cancelPayPalSubscription(paypalSubscriptionId);
    if (!isCancelled) {
      return res.status(400).json({ error: 'Failed to cancel subscription on PayPal' });
    }

    // Update subscription status in the database
    const updated = await Subscription.update(paypalSubscriptionId, { status: 'canceled' });
    if (!updated) {
      return res.status(400).json({ error: 'Failed to update subscription status in database' });
    }

    res.status(200).json({ message: 'Subscription canceled successfully' });
  } catch (error) {
    console.error('Error canceling subscription:', error);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
};

// Retrieve a user's active subscription
exports.getUserSubscription = async (req, res) => {
  const { userId } = req.params;

  try {
    console.log("User ID:", userId);

    // Check if user already has an active subscription
    const [subscription] = await db.query(
      `SELECT * FROM user_subscriptions WHERE user_id = ?`,
      [userId]
    );

    // Ensure subscription is not empty
    if (!subscription || subscription.length === 0) {
      console.log("No active subscription found.");
      return res.status(404).json({ error: 'No active subscription found for this user' });
    }

    console.log("Subscription found:", subscription);
    res.status(200).json(subscription[0]);
  } catch (error) {
    console.error('Error fetching user subscription:', error);
    res.status(500).json({ error: 'Failed to fetch user subscription' });
  }
};

// Purchase Subscription
exports.purchaseSubscription = async (req, res) => {
  try {
    const { userId, subscriptionId } = req.body;

    if (!userId || !subscriptionId) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Check if user already has an active subscription
    const [existingSubscriptions] = await db.query(
      `SELECT * FROM user_subscriptions WHERE user_id = ? AND expiry_date > NOW()`,
      [userId]
    );

    if (existingSubscriptions.length > 0) {
      return res.status(400).json({ message: 'User already has an active subscription' });
    }

    // Calculate expiry date (1 month from now)
    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + 1);

    // Insert the new subscription
    await db.query(
      `INSERT INTO user_subscriptions (user_id, subscription_id, expiry_date) VALUES (?, ?, ?)`,
      [userId, subscriptionId, expiryDate]
    );

    res.json({ message: 'Subscription successful' });

  } catch (error) {
    console.error('Error processing subscription:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }



  // Get Active Subscription for a User
exports.getActiveSubscription = async (req, res) => {
  try {
    console.log("nwwnjwndw");
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }

    const [subscription] = await db.query(
      `SELECT us.id, us.subscription_id, s.name, s.price, us.expiry_date 
       FROM user_subscriptions us 
       JOIN subscriptions s ON us.subscription_id = s.id
       WHERE us.user_id = ? AND us.expiry_date > NOW()
       LIMIT 1`,
      [userId]
    );

    if (subscription.length === 0) {
      return res.status(404).json({ message: 'No active subscription found' });
    }
    console.log(subscription[0]);

    res.json(subscription[0]);

  } catch (error) {
    console.error('Error fetching active subscription:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

};