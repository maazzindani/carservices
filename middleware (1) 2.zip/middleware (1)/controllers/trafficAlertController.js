const TrafficAlert = require('../models/trafficAlertsModel');

// Get all traffic alerts
exports.getAllAlerts = async (req, res) => {
  try {
    const alerts = await TrafficAlert.findAll();
    res.json(alerts);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching traffic alerts' });
  }
};

// Get a traffic alert by ID
exports.getAlertById = async (req, res) => {
  try {
    const alertId = req.params.id;
    const alert = await TrafficAlert.findById(alertId);

    if (!alert) {
      return res.status(404).json({ message: 'Traffic alert not found' });
    }

    res.json(alert);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching traffic alert' });
  }
};

// Create a new traffic alert
exports.createAlert = async (req, res) => {
  try {
    console.log(req.body);
    const { title, description, location, alert_type, user_id } = req.body;

    // Validate required fields
    if (!title || !description || !alert_type || !user_id) {
      return res.status(400).json({ message: 'Title, description, alert_type, and user_id are required' });
    }

    const alertId = await TrafficAlert.create({ title, description, location, alert_type, user_id });
    res.status(201).json({ message: 'Traffic alert created successfully', alertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error creating traffic alert' });
  }
};

// Update a traffic alert by ID
exports.updateAlert = async (req, res) => {
  try {
    const alertId = req.params.id;
    const { title, description, location, alert_type } = req.body;

    const success = await TrafficAlert.update(alertId, { title, description, location, alert_type });

    if (!success) {
      return res.status(404).json({ message: 'Traffic alert not found or update failed' });
    }

    res.json({ message: 'Traffic alert updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating traffic alert' });
  }
};

// Delete a traffic alert by ID
exports.deleteAlert = async (req, res) => {
  try {
    const alertId = req.params.id;

    const success = await TrafficAlert.delete(alertId);

    if (!success) {
      return res.status(404).json({ message: 'Traffic alert not found or deletion failed' });
    }

    res.json({ message: 'Traffic alert deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting traffic alert' });
  }
};
